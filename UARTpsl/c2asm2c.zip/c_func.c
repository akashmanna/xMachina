void c_func (void)
{
}

