extern void a_func (void);

void main (void)
{
a_func ();
}

