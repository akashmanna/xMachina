extern void c_func (void);

void a_func (void)
{
c_func ();
}

